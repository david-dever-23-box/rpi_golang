package ssa

func rewriteValueAMD64(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockAMD64(b *Block) bool { panic("unused during bootstrap") }
