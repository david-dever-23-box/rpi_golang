package main

import (
	"explicit"
	"implicit"
)

func main() {
	println(implicit.I() + explicit.E())
}
